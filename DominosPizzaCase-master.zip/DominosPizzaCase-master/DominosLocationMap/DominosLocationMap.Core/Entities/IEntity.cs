﻿namespace DominosLocationMap.Core.Entities
{
    public interface IEntity
    {
    }
}