﻿namespace DominosLocationMap.Core.Entities
{
    public interface IDto
    {
    }
}