﻿using DominosLocationMap.Entities.ComplexTypes;

namespace DominosLocationMap.Entities.Models.Queue
{
    public class LocationReadDataQueue
    {
        public LocationInfoInputDto LocationInfoInputDto { get; set; }
    }
}