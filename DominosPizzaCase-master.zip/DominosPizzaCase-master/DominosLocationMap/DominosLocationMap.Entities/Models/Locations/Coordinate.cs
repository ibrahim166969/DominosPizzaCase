﻿namespace DominosLocationMap.Entities.Models.Locations
{
    public class Coordinate
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}